# Usage

The development set contains all the dev/test files released in General MT/News shared task of WMT

To extract the text from the xml formatted files, use the tools from https://github.com/wmt-conference/wmt-format-tools
Or extract.py in the xml folder
